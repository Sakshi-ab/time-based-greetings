from django.shortcuts import render
from datetime import datetime

def get_greeting(request):
    if request.method == 'POST':
        user_time_str = request.POST.get('user_time', '')

        try:
            user_time = datetime.strptime(user_time_str, '%I:%M %p').time()
        except ValueError:
            user_time = None

        if user_time:
            if user_time < datetime.strptime('12:00 PM', '%I:%M %p').time():
                greeting = 'Good morning.'
            elif user_time < datetime.strptime('6:00 PM', '%I:%M %p').time():
                greeting = 'Good afternoon.'
            else:
                greeting = 'Good evening.'
        else:
            greeting = 'Invalid time input. Please use the format HH:MM AM/PM.'

        return render(request, 'greetings.html', {'greeting': greeting})

    return render(request, 'time_input_form.html')
